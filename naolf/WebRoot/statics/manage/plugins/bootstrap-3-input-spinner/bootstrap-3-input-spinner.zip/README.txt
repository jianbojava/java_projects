A Pen created at CodePen.io. You can find this one at http://codepen.io/Thomas-Lebeau/pen/csHqx.

 